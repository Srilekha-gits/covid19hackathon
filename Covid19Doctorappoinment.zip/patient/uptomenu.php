<div class="container-fluid">
		<div class="header_top">
			
			<span style="font-size:50px;color:#2c2f84;font-weight:bolder;margin-left:15px;">Doctor Appoinment System</span>
		</div>

	<!-- 	this is for menu -->
	<div class="navbar navbar-default nav">
		<nav class="menu">
			<ul>
				<li><a href="myDetails.php">My Details</a></li>
				<li><a href="search_doctor.php">Search Doctors </a></li>
				<li><a href="view_booking.php">View Appoinment</a></li>
				<li><a href="changepwd.php">Change Password</a></li>
				<li><a href="feedback.php">Feedback</a></li>
				<li><a href="logout.php">Log Out</a></li>
			</ul>
		</nav>
	</div>