<?php include('header.php'); ?>





	<!-- this is for donor registraton -->
	<div class="main_content" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;">About Us</h3>
		<div class="col-md-12">
			<div class="col-md-6">
				<img src="img/aboutimag33.jpg" alt="" class="img-responsive">
			</div>

			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">We are Beside you</h3>
					<p class="text-justify">We hospitals chain together to manage their patient bookings through efficient doctor appointment booking apps.</p>
					<h3 style="color:#0616BC;">24/7 hour service</h3>
					<p class="text-justify">We provide 24 hrs service to take care patient and reduce the severity of covid-19 among patients. We take immediate treatment for patients who gets the symptoms of covid.</p>
				</article>
			</div>
		</div>


		<div class="col-md-12">
			<div class="col-md-6">
				<article>
					<h3 style="color:#0616BC;">Let's Take a Survey</h3>
					<p class="text-justify"><ol>1. Do you have cough.</ol>
					<ol>2. Do you have fever.</ol>
					<ol>3. Have you vistied any international places 30days before.</ol>
					<ol>4. If any symptoms you have consult doctor by getting appointment.</ol>
					<b>We are here to help you!!!</b>
				</article>
			</div>
			<div class="col-md-6">
				<img src="img/aboutimag11.jpg" alt="" class="img-responsive"><br>
			</div>
		</div>
          
    </div>
		
	
	
	

	
 <?php include('footer.php'); ?>


	
	</div><!--  containerFluid Ends -->




	<script src="js/bootstrap.min.js"></script>





	
</body>
</html>